package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TodoServlet
 */
@WebServlet("/TodoServlet")
public class TodoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TodoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s = request.getParameter("pagina");
		PrintWriter out = response.getWriter();
		
		switch (s) {
		case "uno":
			
			//qui è codice java 
			response.setContentType("application/json");

			out.print("[");
			for (model.Prodotto prodotto : ProdottiJar.elencoProdotti){
				out.print("{");
				out.print("\"prodotto\" :  \""+  prodotto.getDescrizione()+"\"" );
				if (prodotto.getCodice().equals("C00005"))
				out.print("}");
				else
				out.print("},");
			}
			out.print("]");
			
//			request.getRequestDispatcher("content1.html").include(request, response);
			break;

		default:
			
			response.setContentType("text/html");
			
			request.getRequestDispatcher("header.html").include(request, response);
			out.print("<h2>benvenuto nell'area</h2");
//			request.getRequestDispatcher("content2.html").include(request, response);
			request.getRequestDispatcher("footer.html").include(request, response);
			
			break;
		}
		//response.getWriter().append("Sono il metdo do get: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String s = request.getParameter("nome");
		
		switch (s) {
		case "red":
			
			break;

		default:
			break;
		}
		
		response.getWriter().append("Sono il metdo do post: ").append(request.getContextPath()).append(s);
	}


}
