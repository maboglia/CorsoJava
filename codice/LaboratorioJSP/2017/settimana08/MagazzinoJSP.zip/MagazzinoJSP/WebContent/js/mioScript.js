var tabella = $("#tabellaMagazzino");



$(".blue td").css("color", "blue");
$(".red td").css("color", "red");

$(".blue td").click(function(){
	
	$(".blue td").css("color", "green");
	
	
});
