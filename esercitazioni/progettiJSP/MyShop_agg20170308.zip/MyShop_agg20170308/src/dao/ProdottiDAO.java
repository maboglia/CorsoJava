package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import connessione.Connessione;
import model.Abito;
import model.Camicia;
import model.Colori;
import model.Giacca;
import model.Maglione;
import model.Pantalone;
import model.Scarpe;
import model.Taglie;

public class ProdottiDAO{

	
	
	public String mostraProdotti() throws SQLException{
		 ResultSet rs = miaQuery("");
			StringBuilder sb = new StringBuilder();
				int i =0;
			while (rs.next()){
				++i;
				System.out.println( (i==1)  ?  "[" : "");
				System.out.println( (i>1)  ?  "," : "");
				System.out.println("{");
				System.out.println("\"id\":" + rs.getInt(1) +",");
				System.out.println("\"colore\": \"" + rs.getString(2) +"\",");
				System.out.println("\"taglia\":  \"" + rs.getString(3) +"\",");
				System.out.println("\"misura\":" + rs.getInt(4) +",");
				System.out.println("\"prezzo\":" + rs.getDouble(5) +",");
				System.out.println("\"id_cat\":" + rs.getInt(6));				
				System.out.println("}");
				sb.append( (i==1)  ?  "[" : "");
				sb.append( (i>1)  ?  "," : "");
				sb.append("{");
				sb.append("\"id\":" + rs.getInt(1) +",");
				sb.append("\"colore\": \"" + rs.getString(2) +"\",");
				sb.append("\"taglia\":  \"" + rs.getString(3) +"\",");
				sb.append("\"misura\":" + rs.getInt(4) +",");
				sb.append("\"prezzo\":" + rs.getDouble(5) +",");
				sb.append("\"id_cat\":" + rs.getInt(6));				
				sb.append("}");
			}
			System.out.println("]");
			sb.append("]");
			return sb.toString();
	}

	/**
	 * @return ResultSet
	 * @throws SQLException
	 */
	private ResultSet miaQuery(String sql) throws SQLException {
		if (sql.trim().equals("")) 		
			sql = "select * from prodotti";
			
		Connection c = Connessione.getConnessione();
			Statement statement = c.createStatement();
			ResultSet rs = statement.executeQuery(sql);
		return rs;
	}

	public ArrayList<Abito> getAbiti() throws SQLException{
		
		ArrayList<Abito> abiti = new ArrayList<>(); 
		 ResultSet rs = miaQuery("");
			while (rs.next()){
				switch (rs.getInt("id_cat")) {

				case 1:
					abiti.add(new Camicia(Taglie.valueOf(rs.getString("taglia")), Colori.valueOf(rs.getString("colore")), rs.getDouble("prezzo")));
					break;

				case 2:
					abiti.add(new Giacca(Taglie.valueOf(rs.getString("taglia")), Colori.valueOf(rs.getString("colore")), rs.getDouble("prezzo")));
					break;
					
				case 3:
					abiti.add(new Maglione(Taglie.valueOf(rs.getString("taglia")), Colori.valueOf(rs.getString("colore")), rs.getDouble("prezzo")));
					break;
					
				case 4:
					abiti.add(new Pantalone(Taglie.valueOf(rs.getString("taglia")), Colori.valueOf(rs.getString("colore")), rs.getDouble("prezzo")));
					break;
					
				case 5:
					abiti.add(new Scarpe(Taglie.valueOf(rs.getString("misura")), Colori.valueOf(rs.getString("colore")), rs.getDouble("prezzo")));
					break;
					
				default:
					break;
				}

			}		
		
		return abiti;
	}
	
		public static int save(Abito a){
			int status=0;
			try{
				PreparedStatement ps=
						Connessione
						.getConnessione()
						.prepareStatement("INSERT INTO `corsotss2017`.`prodotti` (`colore`, `taglia`, `prezzo`, `id_cat`) VALUES (?,?,?,?)");
				ps.setString(1,a.getColore().toString());
				ps.setString(2,a.getTaglia().toString());
				ps.setString(3,a.getPrezzo().toString());
				ps.setInt(4,a.getCategoria());
				status=ps.executeUpdate();
			}catch(Exception e){System.out.println(e);}
			return status;
		}
	
	public static void main(String[] args) {
		ProdottiDAO pdao = new ProdottiDAO();
		
//		pdao.save(new Camicia(Taglie.XL, Colori.GREEN, 30.5));
//		pdao.save(new Giacca(Taglie.XL, Colori.GREEN, 40.5));
//		pdao.save(new Pantalone(Taglie.XL, Colori.GREEN, 50.5));
//		pdao.save(new Maglione(Taglie.XL, Colori.GREEN, 60.5));
//		
		try {
			pdao.mostraProdotti();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
