package connessione;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connessione {

	private static final String URL = "jdbc:mysql://localhost:3306/corsotss2017";
	private static final String USER  = "root";
	private static final String PASS  = "";
	
	public static Connection getConnessione(){
		 Connection connessione = null;
		 
		 try{
				Class.forName("com.mysql.jdbc.Driver");

			 connessione = DriverManager.getConnection(URL,USER, PASS);
		 } catch (SQLException e){
			 System.out.println("connessione al DB fallata!");
			 e.printStackTrace();
		 } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return connessione;
	}
}
