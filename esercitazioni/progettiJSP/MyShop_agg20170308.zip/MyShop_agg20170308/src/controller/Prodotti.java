package controller;

import java.util.ArrayList;

import model.*;

public class Prodotti {

	private ArrayList<Abito> prodotti;	
	private StringBuilder s;
	
	public Prodotti(){
		s=new StringBuilder();
		prodotti = new ArrayList<>();
	}
	

	/**
	 * @return the prodotti
	 */
	public ArrayList<Abito> getProdotti() {
		return prodotti;
	}
	
	public void addProdotti(Abito a) {
		prodotti.add(a);
	}
	
	

	
	public static void main(String[] args) {
		//System.out.println(prodotti);
	}
	
	
	
	
}
