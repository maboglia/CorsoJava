package model;

public enum Colori {
	RED, GREEN, BLUE;
}
