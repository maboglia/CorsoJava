package model;

public abstract class Abito {

	Taglie taglia; 
	Colori colore;
	String misura;
	String marca;
	Double prezzo;
	int categoria;

	public abstract String descriviProdotto();

	/**
	 * @return the categoria
	 */
	public int getCategoria() {
		return categoria;
	}

	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	
	
	/**
	 * @return the taglia
	 */
	public Taglie getTaglia() {
		return taglia;
	}

	/**
	 * @param taglia the taglia to set
	 */
	public void setTaglia(Taglie taglia) {
		this.taglia = taglia;
	}

	/**
	 * @return the colore
	 */
	public Colori getColore() {
		return colore;
	}

	/**
	 * @param colore the colore to set
	 */
	public void setColore(Colori colore) {
		this.colore = colore;
	}

	/**
	 * @return the misura
	 */
	public String getMisura() {
		return misura;
	}

	/**
	 * @param misura the misura to set
	 */
	public void setMisura(String misura) {
		this.misura = misura;
	}

	/**
	 * @return the marca
	 */
	public String getMarca() {
		return marca;
	}

	/**
	 * @param marca the marca to set
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}

	/**
	 * @param prezzo the prezzo to set
	 */
	public void setPrezzo(Double prezzo) {
		this.prezzo = prezzo;
	}


	/**
	 * @return the prezzo
	 */
	public Double getPrezzo() {
		return prezzo;
	}
	
	
}
