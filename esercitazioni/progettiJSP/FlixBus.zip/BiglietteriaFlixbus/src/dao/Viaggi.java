package dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import connessione.Connessione;

public class Viaggi{

	
	/**
	 * @return the id_utenti
	 */
	public int getId_utenti() {
		return id_utenti;
	}



	/**
	 * @return the id_tratte
	 */
	public int getId_tratte() {
		return id_tratte;
	}



	/**
	 * @return the data_viaggio
	 */
	public String getData_viaggio() {
		return data_viaggio;
	}



	/**
	 * @return the numero_biglietti
	 */
	public int getNumero_biglietti() {
		return numero_biglietti;
	}



	private int id_viaggi = 0;
	private int id_utenti = 0;
	private int id_tratte = 0;

	private String data_viaggio = null;
	private int numero_biglietti = 0;
	
//	BaseDAO bd = new BaseDAO();
	Connessione bd = new Connessione();

	public Viaggi(){}
	

	
	public Viaggi(int int1, int int2, int int3, String string, int int4) {
		this.id_viaggi = int1;
		this.id_utenti = int2;
		this.id_tratte = int3;

		this.data_viaggio = string;
		this.numero_biglietti = int4;	

	}



	public boolean inserisciViaggio(int id_utenti, int id_tratta, String giorno, int numero_biglietti){
		
		boolean b = true;
		
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "INSERT INTO viaggi (id_utenti, id_tratte, data_viaggio, numero_biglietti) "
				+ " values('" +id_utenti+"','"+id_tratta+"','"+ giorno +"','" +numero_biglietti+"')";

		
		try{
			stmt=bd.getConnessione().createStatement();
			stmt.executeUpdate(sql);

		}
		
		catch(SQLException e){
			b = false;
			e.printStackTrace();
		}
		
		return b;
		
		
	}

	public ArrayList<Viaggi> elencoViaggi(){
		
		
		Statement stmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM viaggi";
		ArrayList<Viaggi> lista = new ArrayList<>();
		
		try{
			stmt=bd.getConnessione().createStatement();
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				
				lista.add(
						new Viaggi(rs.getInt(1),rs.getInt(2),rs.getInt(3),rs.getString(4),rs.getInt(5)));
			}
		}
		
		catch(SQLException e){
			
			e.printStackTrace();
		}
		
		return lista;
		
		
	}
	
	
	
	public static void main(String[] args) {

		Viaggi v = new Viaggi();

		if (v.inserisciViaggio(1, 1, "20170630", 10)) System.out.println("viaggiook");
		
		for (Viaggi c : v.elencoViaggi()) {
			System.out.println(c.getData_viaggio());
		}
		
		
	}
	
}
