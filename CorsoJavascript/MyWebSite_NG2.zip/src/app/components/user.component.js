"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var posts_service_1 = require("../services/posts.service");
var UserComponent = (function () {
    function UserComponent(postsService) {
        var _this = this;
        this.postsService = postsService;
        this.name = "mauro bogliaccino";
        this.email = "mauro.bogliaccino@gmail.com";
        this.eta = 47;
        this.skill = {
            fSkill: 'Php',
            sSkill: 'Java',
            tSkill: 'JavaScript'
        };
        this.hobbies = ["sport", "turismo", "tempo libero",];
        this.mostraHobbies = true;
        this.postsService.getPosts().subscribe(function (posts) {
            _this.posts = posts;
        });
    }
    UserComponent.prototype.showHobbies = function () {
        this.mostraHobbies = !this.mostraHobbies;
    };
    UserComponent.prototype.eliminaHobby = function (i) {
        this.hobbies.splice(i, 1);
    };
    UserComponent.prototype.aggiungiHobby = function (hobby) {
        this.hobbies.push(hobby);
    };
    return UserComponent;
}());
UserComponent = __decorate([
    core_1.Component({
        selector: 'user',
        template: " \n        <h1>{{name}} {{eta}}</h1>\n        <h2>{{email}}</h2>\n        <button (click)=\"showHobbies()\"  class=\"btn btn-primary\">\n            {{ mostraHobbies ? \"nascondi hobbies\" : \"mostra hobbies\"}}\n        </button>\n        <div *ngIf=\"mostraHobbies\">\n        <h3>hobbies</h3>\n        <ul>\n            <li *ngFor=\"let hobby of hobbies; let i = index \">\n                {{i}} {{hobby}} <button (click)=\"eliminaHobby(i)\">[X]</button>\n            </li>\n\n        </ul>\n        <form (submit)=\"aggiungiHobby(hobby.value)\">\n            <label>Aggiungi hobby</label><br>\n            <input type=\"text\" #hobby />\n        </form>\n\n\n\n        </div>\n\n        <form>\n            <br/>\n            <label>Nome: </label><br/>\n            <input type=\"text\" name=\"name\" [(ngModel)]=\"name\" />\n            <br/>\n            <label>Email: </label><br/>\n            <input type=\"text\" name=\"email\" [(ngModel)]=\"email\" />\n            <br/>\n            <label>Eta: </label><br/>\n            <input type=\"number\" name=\"eta\" [(ngModel)]=\"eta\" />\n            <br/>\n            <label>Skill1: </label><br/>\n            <input type=\"text\" name=\"skill.fSkill\" [(ngModel)]=\"skill.fSkill\" />\n            <br/>\n            <label>Skill2: </label><br/>\n            <input type=\"text\" name=\"skill.sSkill\" [(ngModel)]=\"skill.sSkill\" />\n            <br/>\n            <label>Skill3: </label><br/>\n            <input type=\"text\" name=\"skill.tSkill\" [(ngModel)]=\"skill.tSkill\" />\n            <br/>\n        </form>\n        <h3>skills</h3>\n        <ul>\n            <li>{{skill.fSkill}}</li>\n            <li>{{skill.sSkill}}</li>\n            <li>{{skill.tSkill}}</li>\n        </ul>\n        <h3>I miei post</h3>\n\n        <div *ngFor=\"let post of posts\">\n            <h4>{{post.title}}</h4>\n            <p>{{post.body}}</p>\n        </div>\n\n      ",
        providers: [posts_service_1.PostsService]
    }),
    __metadata("design:paramtypes", [posts_service_1.PostsService])
], UserComponent);
exports.UserComponent = UserComponent;
//# sourceMappingURL=user.component.js.map