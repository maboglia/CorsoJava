import {Component} from '@angular/core';
import {PostsService} from '../services/posts.service';


@Component({

    selector: 'user',
    template: ` 
        <h1>{{name}} {{eta}}</h1>
        <h2>{{email}}</h2>
        <button (click)="showHobbies()"  class="btn btn-primary">
            {{ mostraHobbies ? "nascondi hobbies" : "mostra hobbies"}}
        </button>
        <div *ngIf="mostraHobbies">
        <h3>hobbies</h3>
        <ul>
            <li *ngFor="let hobby of hobbies; let i = index ">
                {{i}} {{hobby}} <button (click)="eliminaHobby(i)">[X]</button>
            </li>

        </ul>
        <form (submit)="aggiungiHobby(hobby.value)">
            <label>Aggiungi hobby</label><br>
            <input type="text" #hobby />
        </form>



        </div>

        <form>
            <br/>
            <label>Nome: </label><br/>
            <input type="text" name="name" [(ngModel)]="name" />
            <br/>
            <label>Email: </label><br/>
            <input type="text" name="email" [(ngModel)]="email" />
            <br/>
            <label>Eta: </label><br/>
            <input type="number" name="eta" [(ngModel)]="eta" />
            <br/>
            <label>Skill1: </label><br/>
            <input type="text" name="skill.fSkill" [(ngModel)]="skill.fSkill" />
            <br/>
            <label>Skill2: </label><br/>
            <input type="text" name="skill.sSkill" [(ngModel)]="skill.sSkill" />
            <br/>
            <label>Skill3: </label><br/>
            <input type="text" name="skill.tSkill" [(ngModel)]="skill.tSkill" />
            <br/>
        </form>
        <h3>skills</h3>
        <ul>
            <li>{{skill.fSkill}}</li>
            <li>{{skill.sSkill}}</li>
            <li>{{skill.tSkill}}</li>
        </ul>
        <h3>I miei post</h3>

        <div *ngFor="let post of posts">
            <h4>{{post.title}}</h4>
            <p>{{post.body}}</p>
        </div>

      `,
      providers:[PostsService]
})

export class UserComponent{
    name: string;
    email: string;
    eta: number;
    skill: skill;
    hobbies: string[];
    mostraHobbies: boolean;
    posts:Post[];

    constructor(private postsService: PostsService){
    this.name = "mauro bogliaccino";
    this.email = "mauro.bogliaccino@gmail.com";
    this.eta = 47;
    this.skill = {
        fSkill: 'Php',
        sSkill: 'Java',
        tSkill: 'JavaScript'
    };
    this.hobbies = ["sport","turismo","tempo libero",];
    this.mostraHobbies = true;
    this.postsService.getPosts().subscribe(posts => {
        this.posts=posts;
    });

    }
    showHobbies(){
        this.mostraHobbies = !this.mostraHobbies;
    }
    eliminaHobby(i:number){
        this.hobbies.splice(i,1);
    }
    aggiungiHobby(hobby:string){
        this.hobbies.push(hobby);
    }
}

interface skill{
    fSkill: string;
    sSkill: string;
    tSkill: string;
}

interface Post{
    id: number;
    title: string;
    body: string;
}