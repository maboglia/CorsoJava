import {Component} from '@angular/core';


@Component({

    selector: 'user',
    template: ` 
        <h1>{{userName}}</h1>
      `
})


export class UserComponent{

    userName: string = "Mauro";


}