import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './pomodoro.component.html',
  styleUrls: ['./pomodoro.component.css']
})
export class PomodoroComponent  { 
  
  minuti: number;
  secondi: number;
  inPausa: boolean;
  buttonLabel: string;

  constructor(){
    //chiama metodo per inizializzare
    this.iniziaPomodoro();
    //chiama periodicamente (1000) funzione per scalare i secondi
    setInterval(()=>this.tictac(), 1000);
  }
  
  iniziaPomodoro():void{
    this.minuti = 24;
    this.secondi = 59;
    this.buttonLabel = "Inizia";
    this.inPausa = true;
  }

  private tictac():void {
    if(!this.inPausa){
      this.buttonLabel = "Pausa";
      if(--this.secondi < 0){
        this.secondi = 59;
        if(--this.minuti < 0){
          console.log("finito pomodoro");
          this.iniziaPomodoro();
        }
      }
    }
  }

  toggle():void{
    this.inPausa = !this.inPausa;
    if(this.minuti < 24 || this.secondi < 59){
      this.buttonLabel = this.inPausa ? "Riparti" : "Fermati";
    }
  }
}