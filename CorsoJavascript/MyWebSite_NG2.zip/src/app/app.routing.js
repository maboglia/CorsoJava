"use strict";
var router_1 = require("@angular/router");
var user_component_1 = require("./components/user.component");
var pomodoro_component_1 = require("./components/pomodoro.component");
var appRoutes = [
    {
        path: '',
        component: user_component_1.UserComponent
    },
    {
        path: 'pomodoro',
        component: pomodoro_component_1.PomodoroComponent
    }
];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map