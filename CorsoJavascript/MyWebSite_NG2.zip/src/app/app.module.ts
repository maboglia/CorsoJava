import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent }  from './app.component';
import { UserComponent }  from './components/user.component';
import { PomodoroComponent }  from './components/pomodoro.component';
import {routing} from './app.routing';


@NgModule({
  imports:      [ BrowserModule, routing ],
  declarations: [ AppComponent, UserComponent, PomodoroComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
