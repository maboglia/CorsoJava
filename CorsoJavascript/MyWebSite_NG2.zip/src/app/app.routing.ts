import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {UserComponent} from './components/user.component';
import {PomodoroComponent} from './components/pomodoro.component';


const appRoutes: Routes = [
    {

        path:'',
        component: UserComponent
    },
    {
        path: 'pomodoro',
        component: PomodoroComponent
    }



];

export const routing: ModuleWithProviders = RouterModule.forRoot(appRoutes);